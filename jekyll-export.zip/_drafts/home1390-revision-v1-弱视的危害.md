---
id: 2868
title: 弱视的危害
date: '2023-09-17T15:45:24+08:00'
author: aigamenow
layout: revision
guid: 'https://www.aigamenow.com/?p=2868'
permalink: '/?p=2868'
---

科学表明

# 弱视的危害非常严重

影响视力发育 。弱视是儿童视力发育异常的一种表现，如果不及时治疗，会影响视力的正常发育，使得眼睛的视功能逐渐退化。  
容易造成眼偏斜 。因为弱视眼的视力较差，所以人会主动用好眼来看，从而导致眼部肌肉失衡，产生眼偏斜的情况。  
影响立体视觉 。弱视患者的立体视觉常常会受到影响，这会导致人们在进行空间定位时出现误差，容易发生跌倒、碰撞等危险情况。  
产生不良的心理影响 。长期患有弱视的人，特别是儿童，很容易产生自卑、焦虑、抑郁等心理问题。  
影响职业选择 。弱视可能影响视力的正常使用，进而影响到职业选择。

请关心您的孩子 ★★★★★ 4.8 rating on Google![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-30-42-1.jpg)

即刻购买 <figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-hero-girls-bg.png)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-about-image.jpg)</figure>关于我们 ## 我们是一家专业解决儿童弱视的AI游戏科创公司

科学证明  
  
儿童非常抗拒打针吃药遮盖单眼等传统的解决方法因为影响了外貌。

被其他儿童嘲笑会非常不利于儿童的身心健康的发育会造成心理自卑的阴影。

 <figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-head-of-school.jpg)</figure>国外知名的眼科弱视研究领域的专家

AI游戏是未来解决全球儿童弱视难题的唯一方案，不打针不吃药，是安全绿色环保健康有效的，每天限制1小时，让儿童的快乐的游戏中，不知不觉的改善了眼睛的视觉，促进眼细胞的激活生长，提高了对光线的敏感度，解决弱视有效率98.1%

![](https://www.aigamenow.com/wp-content/uploads/2022/03/day-care-head-of-school-signature.png)##### Yolanda Jenkins

每日健康

## 弱视常见的三个阶段

<figure>![](https://www.aigamenow.com/wp-content/uploads/2022/03/day-care-home-program-image-3.jpg)</figure>#### 婴儿

因为早产婴儿营养不足，被放入保育箱，接受吸氧和紫外线照射，对视网膜细胞造成损害导致弱视

 <figure>![](https://www.aigamenow.com/wp-content/uploads/2022/03/day-care-home-program-image-2.jpg)</figure>#### 幼儿

因劣质玩具设计缺陷，儿童长期近距离直视，眼睛聚焦焦距过紧，造成眼睛疲劳斜视

 <figure>![](https://www.aigamenow.com/wp-content/uploads/2022/03/day-care-home-program-image-1.jpg)</figure>#### 小学生

因长时间玩劣质的数码平板电脑或手机，因为屏幕像素分辨率太低，色彩太差，刷新率不足60HZ

每日训练

## 有效的解决方案

01 ### 每一小时

购买我们的AI游戏，每天玩小时的游戏，这个不是市面上普通的游戏，而是能够人工智能的解决弱视的量子游戏

 8:30 – 12:00 99元/套 02 ### 全天

 科学证明，太阳光中含有对视网膜细胞生长十分有益的元素，每天户外活动一小时或吃叶黄素对缓解眼睛疲劳很有效

 8:30 – 3:30 $99/盒 03 ### 终极方案

我们发现了预防弱视近视的终极发案。采用宇宙波长的量子激光发射仪，每次照射眼球2-5分钟，能有效预防弱视近视。

 8:30 – 5:30 $200/台 我们希望所有的父母能遵循执行以上的三个方案

关爱您的孩子 为什么我们 ## 拥有最好的解决弱视方案

##### 和善

##### 创新

##### 情感

##### 发明

<figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-6.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-5.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-4.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-3.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-1.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-2.jpg)</figure>#### 早晨的阳光

#### 积极锻炼

#### 玩耍的空间

#### 学习室

#### 健康的食物

#### 户外活动

## 专家团队

![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-teacher-image-3.jpg)##### Ella Stark

![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-teacher-image-2.jpg)##### Harriet Bailey

![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-teacher-image-1.jpg)##### Melinda Schiller

###### 国外家长的评价

<figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-testimonial-image.jpg)</figure>AI游戏有效的让我的女儿，双眼的弱视，从严重的斜视，变成了正常。

现在戴上眼镜从以前的看不清黑板，变成了正常的健康。

感谢AI游戏团队，让我女儿的眼睛重现清晰。

Ramona Altenwerth

#  

每日活动

## 目的：为了解决儿童的缺陷

 #### 早晨的阳光

#### 积极锻炼

#### 玩耍的空间

#### 学习室

#### 健康的食物

#### 户外活动

## 专家团队

![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-teacher-image-3.jpg)##### Ella Stark

![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-teacher-image-2.jpg)##### Harriet Bailey

![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-teacher-image-1.jpg)##### Melinda Schiller

###### 国外家长的评价

<figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-testimonial-image.jpg)</figure>AI游戏有效的让我的女儿，双眼的弱视，从严重的斜视，变成了正常。

现在戴上眼镜从以前的看不清黑板，变成了正常的健康。

感谢AI游戏团队，让我女儿的眼睛重现清晰。

Ramona Altenwerth

#  

 