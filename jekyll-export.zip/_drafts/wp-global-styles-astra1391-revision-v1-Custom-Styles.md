---
id: 2629
title: 'Custom Styles'
date: '2023-09-16T19:47:01+08:00'
author: aigamenow
layout: revision
guid: 'https://www.aigamenow.com/?p=2629'
permalink: '/?p=2629'
---

{“version”: 2, “isGlobalStylesUserThemeJSON”: true }