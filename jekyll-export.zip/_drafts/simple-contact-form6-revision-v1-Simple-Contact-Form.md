---
id: 7
title: 'Simple Contact Form'
date: '2023-09-16T19:46:33+08:00'
author: aigamenow
layout: revision
guid: 'https://www.aigamenow.com/?p=7'
permalink: '/?p=7'
---

{“fields”:{“0”:{“id”:”0″,”type”:”name”,”label”:”Parent’s Name”,”format”:”simple”,”description”:””,”required”:”1″,”size”:”large”,”simple\_placeholder”:””,”simple\_default”:””,”first\_placeholder”:””,”first\_default”:””,”middle\_placeholder”:””,”middle\_default”:””,”last\_placeholder”:””,”last\_default”:””,”css”:””},”1″:{“id”:”1″,”type”:”email”,”label”:”Email”,”description”:””,”required”:”1″,”size”:”large”,”placeholder”:””,”confirmation\_placeholder”:””,”default\_value”:””,”filter\_type”:””,”allowlist”:””,”denylist”:””,”css”:””},”3″:{“id”:”3″,”type”:”radio”,”label”:”I have a question about:”,”choices”:{“1”:{“label”:”Infant”,”value”:””,”image”:””},”2″:{“label”:”Toddler”,”value”:””,”image”:””},”3″:{“label”:”Preschool”,”value”:””,”image”:””}},”description”:””,”choices\_images\_style”:”modern”,”input\_columns”:””,”dynamic\_choices”:””,”css”:””},”2″:{“id”:”2″,”type”:”textarea”,”label”:”Questions or message”,”description”:””,”required”:”1″,”size”:”medium”,”placeholder”:””,”limit\_count”:”1″,”limit\_mode”:”characters”,”default\_value”:””,”css”:””}},”id”:6,”field\_id”:4,”settings”:{“form\_title”:”Simple Contact Form”,”form\_desc”:””,”submit\_text”:”Submit”,”submit\_text\_processing”:”Sending…”,”antispam”:”1″,”form\_class”:””,”submit\_class”:””,”ajax\_submit”:”1″,”notification\_enable”:”1″,”notifications”:{“1”:{“email”:”{admin\_email}”,”subject”:”New Entry: Simple Contact Form”,”sender\_name”:”Day Care Services”,”sender\_address”:”{admin\_email}”,”replyto”:”{field\_id=\\”1\\”}”,”message”:”{all\_fields}”}},”confirmations”:{“1”:{“type”:”message”,”message”:”

Thanks for contacting us! We will be in touch with you shortly.“,”message\_scroll”:”1″,”page”:”2″,”redirect”:””}}},”meta”:{“template”:”4dbf022985a4fe4bda4a80365011a3a0″}}