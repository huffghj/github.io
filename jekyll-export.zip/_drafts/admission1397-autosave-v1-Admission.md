---
id: 2811
title: Admission
date: '2023-09-17T14:18:21+08:00'
author: aigamenow
layout: revision
guid: 'https://www.aigamenow.com/?p=2811'
permalink: '/?p=2811'
---

  
# 我们希望家长们早点解决孩子的弱视问题

<figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/daycare-admission-image-2.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/daycare-admission-image-1.jpg)</figure> 