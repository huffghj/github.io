---
id: 2626
title: About
date: '2023-09-16T19:47:00+08:00'
author: aigamenow
layout: revision
guid: 'https://www.aigamenow.com/?p=2626'
permalink: '/?p=2626'
---

<div class="wp-block-uagb-container uagb-block-a79bbcd0 alignfull uagb-is-root-container"><div class="uagb-container-inner-blocks-wrap"><div class="wp-block-uagb-advanced-heading uagb-block-84f814f5">About us

# We are here to help parents raise happy and healthy children

</div><div class="wp-block-uagb-container uagb-block-dfef776f"><div class="wp-block-uagb-container uagb-block-3eb5150e"><div class="wp-block-uagb-image uagb-block-1c91ce91 wp-block-uagb-image--layout-default wp-block-uagb-image--effect-static wp-block-uagb-image--align-none"><figure class="wp-block-uagb-image__figure">![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-about-image.jpg)</figure></div></div><div class="wp-block-uagb-container uagb-block-0807ea80"><div class="wp-block-uagb-advanced-heading uagb-block-f6675afe">### We all need support through the most important period of our children: the early years

Aliquam rhoncus mauris, convallis volutpat velit bibendum dui duis ut vulputate amet, ac ipsum nisl convallis ut.  
  
Pulvinar ultrices porta mattis quis lobortis est facilisis purus nunc, sed semper enim dictum sed donec condimentum sodales sed non vel malesuada morbi arcu justo, pretium sagittis hac nisi amet, fermentum nunc.  
  
Blandit auctor felis habitasse aliquet est potenti ut urna eget orci pellentesque commodo vitae.

</div></div></div></div></div><div class="wp-block-uagb-container uagb-block-a4fd6341 alignfull uagb-is-root-container"><div class="uagb-container-inner-blocks-wrap"><div class="wp-block-uagb-container uagb-block-a1d31e07"><div class="wp-block-uagb-advanced-heading uagb-block-c4303f02">## Founder &amp; Head of School

Magna et nibh quam eu at viverra ut hac faucibus sed cras.  
  
Felis mauris quisque scelerisque ac et, porta sit placerat pharetra, ac sodales vel vitae tincidunt mauris arcu placerat mi quis lorem orci, parturient rutrum.

</div></div><div class="wp-block-uagb-container uagb-block-a0ba220c"><div class="wp-block-uagb-image aligncenter uagb-block-36311273 wp-block-uagb-image--layout-default wp-block-uagb-image--effect-static wp-block-uagb-image--align-center"><figure class="wp-block-uagb-image__figure">![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-head-of-school.jpg)</figure></div></div><div class="wp-block-uagb-container uagb-block-2089278f"><div class="wp-block-uagb-info-box uagb-block-55905abe uagb-infobox__content-wrap  uagb-infobox-icon-above-title uagb-infobox-image-valign-top"><div class="uagb-ifb-content"><div class="uagb-ifb-icon-wrap"><svg viewbox="0 0 448 512" xmlns="https://www.w3.org/2000/svg"><path d="M96 224C84.72 224 74.05 226.3 64 229.9V224c0-35.3 28.7-64 64-64c17.67 0 32-14.33 32-32S145.7 96 128 96C57.42 96 0 153.4 0 224v96c0 53.02 42.98 96 96 96s96-42.98 96-96S149 224 96 224zM352 224c-11.28 0-21.95 2.305-32 5.879V224c0-35.3 28.7-64 64-64c17.67 0 32-14.33 32-32s-14.33-32-32-32c-70.58 0-128 57.42-128 128v96c0 53.02 42.98 96 96 96s96-42.98 96-96S405 224 352 224z"></path></svg></div><div class="uagb-ifb-title-wrap">Tortor platea nunc lorem morbi pellentesque sed enim viverra venenatis, sem pellentesque massa nunc quis lectus.

</div></div></div><div class="wp-block-uagb-info-box uagb-block-1ed667b4 uagb-infobox__content-wrap  uagb-infobox-icon-above-title uagb-infobox-image-valign-top"><div class="uagb-ifb-content"><div class="uagb-ifb-image-content">![](https://www.aigamenow.com/wp-content/uploads/2022/03/day-care-head-of-school-signature.png)</div><div class="uagb-ifb-title-wrap">##### Yolanda Jenkins

</div></div></div></div></div></div><div class="wp-block-uagb-container uagb-block-6795bc4b alignfull uagb-is-root-container"><div class="uagb-container-inner-blocks-wrap"><div class="wp-block-uagb-container uagb-block-ebd677c7"><div class="wp-block-uagb-info-box uagb-block-89d2db36 uagb-infobox__content-wrap  uagb-infobox-icon-above-title uagb-infobox-image-valign-top"><div class="uagb-ifb-content"><div class="uagb-ifb-icon-wrap"><svg viewbox="0 0 512 512" xmlns="https://www.w3.org/2000/svg"><path d="M500.3 7.251C507.7 13.33 512 22.41 512 31.1V175.1C512 202.5 483.3 223.1 447.1 223.1C412.7 223.1 383.1 202.5 383.1 175.1C383.1 149.5 412.7 127.1 447.1 127.1V71.03L351.1 90.23V207.1C351.1 234.5 323.3 255.1 287.1 255.1C252.7 255.1 223.1 234.5 223.1 207.1C223.1 181.5 252.7 159.1 287.1 159.1V63.1C287.1 48.74 298.8 35.61 313.7 32.62L473.7 .6198C483.1-1.261 492.9 1.173 500.3 7.251H500.3zM74.66 303.1L86.5 286.2C92.43 277.3 102.4 271.1 113.1 271.1H174.9C185.6 271.1 195.6 277.3 201.5 286.2L213.3 303.1H239.1C266.5 303.1 287.1 325.5 287.1 351.1V463.1C287.1 490.5 266.5 511.1 239.1 511.1H47.1C21.49 511.1-.0019 490.5-.0019 463.1V351.1C-.0019 325.5 21.49 303.1 47.1 303.1H74.66zM143.1 359.1C117.5 359.1 95.1 381.5 95.1 407.1C95.1 434.5 117.5 455.1 143.1 455.1C170.5 455.1 191.1 434.5 191.1 407.1C191.1 381.5 170.5 359.1 143.1 359.1zM440.3 367.1H496C502.7 367.1 508.6 372.1 510.1 378.4C513.3 384.6 511.6 391.7 506.5 396L378.5 508C372.9 512.1 364.6 513.3 358.6 508.9C352.6 504.6 350.3 496.6 353.3 489.7L391.7 399.1H336C329.3 399.1 323.4 395.9 321 389.6C318.7 383.4 320.4 376.3 325.5 371.1L453.5 259.1C459.1 255 467.4 254.7 473.4 259.1C479.4 263.4 481.6 271.4 478.7 278.3L440.3 367.1zM116.7 219.1L19.85 119.2C-8.112 90.26-6.614 42.31 24.85 15.34C51.82-8.137 93.26-3.642 118.2 21.83L128.2 32.32L137.7 21.83C162.7-3.642 203.6-8.137 231.6 15.34C262.6 42.31 264.1 90.26 236.1 119.2L139.7 219.1C133.2 225.6 122.7 225.6 116.7 219.1H116.7z"></path></svg></div><div class="uagb-ifb-title-wrap">#### Inclusive

</div>Nibh in sed venenatis, senectus fermentum nullam donec nulla quis ut facilisis

</div></div></div><div class="wp-block-uagb-container uagb-block-f858d1f2"><div class="wp-block-uagb-info-box uagb-block-d650850b uagb-infobox__content-wrap  uagb-infobox-icon-above-title uagb-infobox-image-valign-top"><div class="uagb-ifb-content"><div class="uagb-ifb-icon-wrap"><svg viewbox="0 0 576 512" xmlns="https://www.w3.org/2000/svg"><path d="M275.2 250.5c7 7.375 18.5 7.375 25.5 0l108.1-114.2c31.5-33.12 29.72-88.1-5.65-118.7c-30.88-26.75-76.75-21.9-104.9 7.724L287.1 36.91L276.8 25.28C248.7-4.345 202.7-9.194 171.1 17.56C136.7 48.18 134.7 103.2 166.4 136.3L275.2 250.5zM568.2 336.3c-13.12-17.81-38.14-21.66-55.93-8.469l-119.7 88.17h-120.6c-8.748 0-15.1-7.25-15.1-15.1c0-8.746 7.25-15.1 15.1-15.1h78.25c15.1 0 30.75-10.87 33.37-26.62c3.25-19.1-12.12-37.37-31.62-37.37H191.1c-26.1 0-53.12 9.25-74.12 26.25l-46.5 37.74l-55.37-.0253c-8.748 0-15.1 7.275-15.1 16.02L.0001 496C.0001 504.8 7.251 512 15.1 512h346.1c22.03 0 43.92-7.187 61.7-20.28l135.1-99.51C577.5 379.1 581.3 354.1 568.2 336.3z"></path></svg></div><div class="uagb-ifb-title-wrap">#### Responsible

</div>Nibh in sed venenatis, senectus fermentum nullam donec nulla quis ut facilisis

</div></div></div><div class="wp-block-uagb-container uagb-block-d644becf"><div class="wp-block-uagb-info-box uagb-block-73df4223 uagb-infobox__content-wrap  uagb-infobox-icon-above-title uagb-infobox-image-valign-top"><div class="uagb-ifb-content"><div class="uagb-ifb-icon-wrap"><svg viewbox="0 0 512 512" xmlns="https://www.w3.org/2000/svg"><path d="M0 190.9V185.1C0 115.2 50.52 55.58 119.4 44.1C164.1 36.51 211.4 51.37 244 84.02L256 96L267.1 84.02C300.6 51.37 347 36.51 392.6 44.1C461.5 55.58 512 115.2 512 185.1V190.9C512 232.4 494.8 272.1 464.4 300.4L283.7 469.1C276.2 476.1 266.3 480 256 480C245.7 480 235.8 476.1 228.3 469.1L47.59 300.4C17.23 272.1 .0003 232.4 .0003 190.9L0 190.9z"></path></svg></div><div class="uagb-ifb-title-wrap">#### Respectful

</div>Nibh in sed venenatis, senectus fermentum nullam donec nulla quis ut facilisis

</div></div></div><div class="wp-block-uagb-container uagb-block-3c8d770a"><div class="wp-block-uagb-info-box uagb-block-ece560e1 uagb-infobox__content-wrap  uagb-infobox-icon-above-title uagb-infobox-image-valign-top"><div class="uagb-ifb-content"><div class="uagb-ifb-icon-wrap"><svg viewbox="0 0 640 512" xmlns="https://www.w3.org/2000/svg"><path d="M128 95.1c26.5 0 47.1-21.5 47.1-47.1S154.5 0 128 0S80.01 21.5 80.01 47.1S101.5 95.1 128 95.1zM511.1 95.1c26.5 0 47.1-21.5 47.1-47.1S538.5 0 511.1 0c-26.5 0-48 21.5-48 47.1S485.5 95.1 511.1 95.1zM603.5 258.3l-18.5-80.13c-4.625-20-18.62-36.88-37.5-44.88c-18.5-8-38.1-6.75-56.12 3.25c-22.62 13.38-39.62 34.5-48.12 59.38l-11.25 33.88l-15.1 10.25L415.1 144c0-8.75-7.25-16-16-16H240c-8.75 0-16 7.25-16 16L224 239.1l-16.12-10.25l-11.25-33.88c-8.375-25-25.38-46-48.12-59.38c-17.25-10-37.63-11.25-56.12-3.25c-18.88 8-32.88 24.88-37.5 44.88l-18.37 80.13c-4.625 20 .7506 41.25 14.37 56.75l67.25 75.88l10.12 92.63C130 499.8 143.8 512 160 512c1.25 0 2.25-.125 3.5-.25c17.62-1.875 30.25-17.62 28.25-35.25l-10-92.75c-1.5-13-7-25.12-15.62-35l-43.37-49l17.62-70.38l6.876 20.38c4 12.5 11.87 23.5 24.5 32.63l51 32.5c4.623 2.875 12.12 4.625 17.25 5h159.1c5.125-.375 12.62-2.125 17.25-5l51-32.5c12.62-9.125 20.5-20 24.5-32.63l6.875-20.38l17.63 70.38l-43.37 49c-8.625 9.875-14.12 22-15.62 35l-10 92.75c-2 17.62 10.75 33.38 28.25 35.25C477.7 511.9 478.7 512 479.1 512c16.12 0 29.1-12.12 31.75-28.5l10.12-92.63L589.1 315C602.7 299.5 608.1 278.3 603.5 258.3zM46.26 358.1l-44 110c-6.5 16.38 1.5 35 17.88 41.63c16.75 6.5 35.12-1.75 41.62-17.88l27.62-69.13l-2-18.25L46.26 358.1zM637.7 468.1l-43.1-110l-41.13 46.38l-2 18.25l27.62 69.13C583.2 504.4 595.2 512 607.1 512c3.998 0 7.998-.75 11.87-2.25C636.2 503.1 644.2 484.5 637.7 468.1z"></path></svg></div><div class="uagb-ifb-title-wrap">#### Collaborative

</div>Nibh in sed venenatis, senectus fermentum nullam donec nulla quis ut facilisis

</div></div></div></div></div><div class="wp-block-uagb-container uagb-block-7a0e9114 alignfull uagb-is-root-container"><div class="uagb-container-inner-blocks-wrap"><div class="wp-block-uagb-container uagb-block-0daffff1"><div class="wp-block-uagb-container uagb-block-96d65eb1"><div class="wp-block-uagb-advanced-heading uagb-block-848cbb06">###### Vision

</div></div><div class="wp-block-uagb-container uagb-block-617029dd"><div class="wp-block-uagb-advanced-heading uagb-block-60063ed4">We want to inspire the next integer nulla habitant nec sem nam bibendum arcu rhoncus in consequat.

</div></div></div><div class="wp-block-uagb-container uagb-block-e4b2999e"><div class="wp-block-uagb-container uagb-block-6377593f"><div class="wp-block-uagb-advanced-heading uagb-block-79894f12">###### Mission

</div></div><div class="wp-block-uagb-container uagb-block-234b5f7b"><div class="wp-block-uagb-advanced-heading uagb-block-8a772a61">We are here to help parents sed nulla gravida ipsum aliquam consectetur neque odio turpis fringilla pretium bibendum commodo.

</div></div></div></div></div><div class="wp-block-uagb-container uagb-block-67bec61e alignfull uagb-is-root-container"><div class="uagb-container-inner-blocks-wrap"><div class="wp-block-uagb-container uagb-block-4b312c1f"><div class="wp-block-uagb-advanced-heading uagb-block-48cf8dce">Meet the teachers

## Experts in giving your children best start

</div><div class="wp-block-uagb-container uagb-block-2c476ebe"><div class="wp-block-uagb-container uagb-block-d93b45e5"><div class="wp-block-uagb-info-box uagb-block-b0c11007 uagb-infobox__content-wrap  uagb-infobox-icon-above-title uagb-infobox-image-valign-top"><div class="uagb-ifb-content"><div class="uagb-ifb-image-content">![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-teacher-image-3.jpg)</div><div class="uagb-ifb-title-wrap">##### Ella Stark

</div>Lead teacher and 1-2 year olds

</div></div></div><div class="wp-block-uagb-container uagb-block-3032c3ef"><div class="wp-block-uagb-info-box uagb-block-e6fae8c1 uagb-infobox__content-wrap  uagb-infobox-icon-above-title uagb-infobox-image-valign-top"><div class="uagb-ifb-content"><div class="uagb-ifb-image-content">![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-teacher-image-2.jpg)</div><div class="uagb-ifb-title-wrap">##### Harriet Bailey

</div>Teacher and 2-3 year olds

</div></div></div><div class="wp-block-uagb-container uagb-block-65035aab"><div class="wp-block-uagb-info-box uagb-block-7d468913 uagb-infobox__content-wrap  uagb-infobox-icon-above-title uagb-infobox-image-valign-top"><div class="uagb-ifb-content"><div class="uagb-ifb-image-content">![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-teacher-image-1.jpg)</div><div class="uagb-ifb-title-wrap">##### Melinda Schiller

</div>Teacher: 3-4 year olds

</div></div></div></div></div></div></div><div class="wp-block-uagb-container uagb-block-3645bfff alignfull uagb-is-root-container"><div class="uagb-container-inner-blocks-wrap"><div class="wp-block-uagb-advanced-heading uagb-block-2b1b7259">###### What parent say

</div><div class="wp-block-uagb-container uagb-block-f8ca30ee"><div class="wp-block-uagb-container uagb-block-382124c3"><div class="wp-block-uagb-image uagb-block-37500b72 wp-block-uagb-image--layout-default wp-block-uagb-image--effect-static wp-block-uagb-image--align-none"><figure class="wp-block-uagb-image__figure">![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-testimonial-image.jpg)</figure></div></div><div class="wp-block-uagb-container uagb-block-346f99d4"><div class="wp-block-uagb-info-box uagb-block-5f7c3da1 uagb-infobox__content-wrap  uagb-infobox-icon-above-title uagb-infobox-image-valign-top"><div class="uagb-ifb-content"><div class="uagb-ifb-icon-wrap"><svg viewbox="0 0 448 512" xmlns="https://www.w3.org/2000/svg"><path d="M96 224C84.72 224 74.05 226.3 64 229.9V224c0-35.3 28.7-64 64-64c17.67 0 32-14.33 32-32S145.7 96 128 96C57.42 96 0 153.4 0 224v96c0 53.02 42.98 96 96 96s96-42.98 96-96S149 224 96 224zM352 224c-11.28 0-21.95 2.305-32 5.879V224c0-35.3 28.7-64 64-64c17.67 0 32-14.33 32-32s-14.33-32-32-32c-70.58 0-128 57.42-128 128v96c0 53.02 42.98 96 96 96s96-42.98 96-96S405 224 352 224z"></path></svg></div><div class="uagb-ifb-title-wrap">Faucibus nulla tincidunt sagittis faucibus proin habitasse nunc erat sed nisi non pulvinar at ante diam nulla tincidunt lectus maecenas penatibus nam suspendisse cursus risus, ac nibh suspendisse

</div>Ramona Altenwerth

</div></div></div></div></div></div><div class="wp-block-uagb-container uagb-block-d7d1f1a1 alignfull uagb-is-root-container"><div class="uagb-container-inner-blocks-wrap"><div class="wp-block-uagb-info-box uagb-block-824f5012 uagb-infobox__content-wrap  uagb-infobox-icon-above-title uagb-infobox-image-valign-top"><div class="uagb-ifb-content"><div class="uagb-ifb-title-wrap"># More than just a joyful place

</div>Egestas pulvinar phasellus id odio viverra pharetra congue est eleifend aenean cras

<div class="uagb-ifb-button-wrapper wp-block-button"><a alt="" class="uagb-infobox-cta-link wp-block-button__link  uagb-disable-link" href="" rel="noopener noreferrer" target="_self"><span class="uagb-inline-editing">Enroll your kid</span></a></div></div></div></div></div>