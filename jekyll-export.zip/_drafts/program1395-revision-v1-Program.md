---
id: 2871
title: Program
date: '2023-09-17T15:48:17+08:00'
author: aigamenow
layout: revision
guid: 'https://www.aigamenow.com/?p=2871'
permalink: '/?p=2871'
---

我们的AI游戏

# 设计出来帮助孩子重现清晰世界

<figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-6.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-5.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-4.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-3.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-1.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/day-care-home-gallery-image-2.jpg)</figure># ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-03-26.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-03-46-300x217.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-04-22-250x300.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-05-04-300x281.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-05-22-300x223.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-06-07-300x231.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-06-21-300x217.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-06-34-300x224.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-07-08-284x300.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-07-20-288x300.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-07-53-300x222.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-08-01-300x224.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-08-15-300x238.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-08-50-300x243.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-09-05-300x231.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-09-19-300x236.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-10-14-300x211.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_15-10-21-300x236.jpg)