---
id: 1393
title: 弱视的介绍
date: '2022-04-21T11:26:28+08:00'
author: aigamenow
layout: page
guid: 'https://www.aigamenow.com/index.php/about/'
site-sidebar-layout:
    - no-sidebar
site-content-layout:
    - page-builder
site-post-title:
    - disabled
ast-featured-img:
    - disabled
theme-transparent-header-meta:
    - enabled
astra-main-page-id:
    - '71475'
ast_self_id_71475:
    - '1'
footnotes:
    - ''
ast-site-content-layout:
    - full-width-container
site-content-style:
    - unboxed
site-sidebar-style:
    - unboxed
adv-header-id-meta:
    - ''
stick-header-meta:
    - ''
astra-migrate-meta-layouts:
    - set
---

###  


<figure>![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-03-41.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-04-17.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-03-56.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-04-30.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-04-49-300x119.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-05-07-300x140.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-05-33-300x124.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-06-04-300x177.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-05-53-300x112.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-06-23-300x171.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-06-55-300x168.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-06-40-300x199.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-07-11-300x172.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-07-38-300x139.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-07-50-300x75.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-08-08-300x95.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-08-21-300x158.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-08-38-300x110.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-10-25-300x156.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-10-03-300x99.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-10-46-300x145.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-11-16-300x136.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-11-52-300x159.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-06-300x119.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-17-300x158.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-26-300x178.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-38-300x102.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-49-300x110.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-59-300x169.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-13-17-300x123.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-13-28-300x104.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-13-44-300x154.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-13-54-300x104.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-14-04-300x245.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-14-19-300x149.jpg)</figure>###  



# 我们在这里帮助儿童快乐健康的成长

<figure>![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-03-41.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-04-17.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-03-56.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-04-30.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-04-49-300x119.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-05-07-300x140.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-05-33-300x124.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-06-04-300x177.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-05-53-300x112.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-06-23-300x171.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-06-55-300x168.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-06-40-300x199.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-07-11-300x172.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-07-38-300x139.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-07-50-300x75.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-08-08-300x95.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-08-21-300x158.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-08-38-300x110.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-10-25-300x156.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-10-03-300x99.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-10-46-300x145.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-11-16-300x136.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-11-52-300x159.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-06-300x119.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-17-300x158.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-26-300x178.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-38-300x102.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-49-300x110.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-12-59-300x169.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-13-17-300x123.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-13-28-300x104.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-13-44-300x154.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-13-54-300x104.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-14-04-300x245.jpg) ![](https://www.aigamenow.com/wp-content/uploads/2023/09/Snipaste_2023-09-17_10-14-19-300x149.jpg)</figure>###  