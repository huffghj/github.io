---
id: 1397
title: 任务目标
date: '2022-04-21T11:29:05+08:00'
author: aigamenow
layout: page
guid: 'https://www.aigamenow.com/index.php/admission/'
site-sidebar-layout:
    - no-sidebar
site-content-layout:
    - page-builder
site-post-title:
    - disabled
ast-featured-img:
    - disabled
theme-transparent-header-meta:
    - enabled
astra-main-page-id:
    - '71476'
ast_self_id_71476:
    - '1'
footnotes:
    - ''
---

  
# 我们希望家长们早点解决孩子的弱视问题

<figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/daycare-admission-image-2.jpg)</figure><figure>![](https://www.aigamenow.com/wp-content/uploads/2022/04/daycare-admission-image-1.jpg)</figure> 